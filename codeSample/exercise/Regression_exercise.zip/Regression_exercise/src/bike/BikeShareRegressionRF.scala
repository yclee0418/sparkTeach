package bike

//time lib
import org.joda.time._
//spark lib
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

//com.util
import com.util._

//log
import org.apache.log4j.Logger

//MLlib lib
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.evaluation._
import org.apache.spark.mllib.linalg.Vectors
//decision tree
import org.apache.spark.mllib.tree.RandomForest
import org.apache.spark.mllib.tree.model.RandomForestModel

object BikeShareRegressionRF {
  def main(args: Array[String]): Unit = {
    MyLogger.setLogger

    val doTrain = (args != null && args.length > 0 && "Y".equals(args(0)))

    val sc = new SparkContext(new SparkConf().setAppName("BikeShareRegressionRF").setMaster("local[4]"))

    println("============== preparing data ==================")
    val (trainData, validateData) = prepare(sc)
    trainData.persist(); validateData.persist();

    val cateInfo = BikeShareEntity.getCategoryInfo()
    if (!doTrain) {
      println("============== train Model (CateInfo)==================")
      val (modelC, durationC) = trainModel(trainData, "variance",3, 5, 30, cateInfo)
      val rmseC = evaluateModel(validateData, modelC)
      println("validate rmse(CateInfo)=%f".format(rmseC))
    } else {
      println("============== tuning parameters(CateInfo) ==================")
      tuneParameter(trainData, validateData, cateInfo)
    }

    trainData.unpersist(); validateData.unpersist();
  }
  
  def prepareCategoryMap(fieldName: String, bikeData: RDD[BikeShareEntity]): Map[Double, Int] = {
    val categoryMap = bikeData.map { x => x.getField(fieldName) }.distinct().collect().zipWithIndex.toMap
    categoryMap
  }

  def prepare(sc: SparkContext): 
  (RDD[LabeledPoint], RDD[LabeledPoint]) = {
    val rawData = Utility.readFile(sc, "hour.csv")

    MyLogger.debug("read BikeShare Dateset count=" + rawData.count())
    val bikeData = rawData.map { x => new BikeShareEntity(x) }
    val Array(bikeDataT, bikeDataV) = bikeData.randomSplit(Array(0.6, 0.4))
    //不處理Category feature
    val trainData = bikeDataT.map { x =>
      {
        val label = x.getLabel()
        val features = Vectors.dense(x.getFeatures())
        new LabeledPoint(label, features)
      }
    }
    val validateData = bikeDataV.map { x =>
      {
        val label = x.getLabel()
        val features = Vectors.dense(x.getFeatures())
        new LabeledPoint(label, features)
      }
    }
    (trainData, validateData)
  }

  def trainModel(trainData: RDD[LabeledPoint],
                 impurity: String, numTrees:Int ,maxDepth: Int, maxBins: Int, catInfo: Map[Int, Int]): 
                 (RandomForestModel, Double) = {
    val startTime = new DateTime()
    
    val model = RandomForest.trainRegressor(trainData, catInfo, numTrees, "auto", impurity, maxDepth, maxBins)
    val endTime = new DateTime()
    val duration = new Duration(startTime, endTime)
    //MyLogger.debug(model.toDebugString)
    (model, duration.getMillis)
  }

  def evaluateModel(validateData: RDD[LabeledPoint], model: RandomForestModel): Double = {
    val scoreAndLabels = validateData.map { data =>
      var predict = model.predict(data.features)
      
      (predict, data.label)
    }
    val metrics = new RegressionMetrics(scoreAndLabels)
    val rmse = metrics.rootMeanSquaredError
    rmse
  }

  def tuneParameter(trainData: RDD[LabeledPoint], validateData: RDD[LabeledPoint], cateInfo:Map[Int,Int]) = {
    val impurityArr = Array("variance")
    val numTreesArr = Array(3,5,10)
    val depthArr = Array(3, 5, 10, 15, 20, 25)
    val binsArr = Array(/*3, 5, 10,*/ 50, 100, 200)
    val evalArr =
      for (impurity <- impurityArr; numTree <- numTreesArr; maxDepth <- depthArr; maxBins <- binsArr) yield {
        val (model, duration) = trainModel(trainData, impurity, numTree, maxDepth, maxBins, cateInfo)
        val rmse = evaluateModel(validateData, model)
        println("parameter: impurity=%s, numTree=%d, maxDepth=%d, maxBins=%d, rmse=%f"
          .format(impurity, numTree, maxDepth, maxBins, rmse))
        (impurity, numTree ,maxDepth, maxBins, rmse)
      }
    val bestEvalAsc = (evalArr.sortBy(_._5))
    val bestEval = bestEvalAsc(0)
    println("best parameter: impurity=%s, numTree=%d, maxDepth=%d, maxBins=%d, rmse=%f"
      .format(bestEval._1, bestEval._2, bestEval._3, bestEval._4, bestEval._5))
  }
}