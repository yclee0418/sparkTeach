package bike

//time lib
import org.joda.time._
//spark lib
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

//com.util
import com.util._

//log
import org.apache.log4j.Logger

//MLlib lib
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.evaluation._
import org.apache.spark.mllib.linalg.Vectors
//linear regression
import org.apache.spark.mllib.feature.StandardScaler
import org.apache.spark.mllib.regression.{LinearRegressionWithSGD, LinearRegressionModel}


object BikeShareRegressionLR {
  def main(args: Array[String]): Unit = {
    MyLogger.setLogger

    val doTrain = (args != null && args.length > 0 && "Y".equals(args(0)))

    val sc = new SparkContext(new SparkConf().setAppName("BikeShareRegressionLR").setMaster("local[4]"))

    println("============== preparing data ==================")
    val (trainDataWithMap, validateDataWithMap) = prepare(sc)
    trainDataWithMap.persist(); validateDataWithMap.persist();

    val cateInfo = BikeShareEntity.getCategoryInfo()
    if (!doTrain) {
      println("============== train Model (Category) ==================")
      val (model2, duration2) = trainModel(trainDataWithMap,100,0.01,1)
      val rmse2 = evaluateModel(validateDataWithMap, model2)
      println("validate rmse(category)=%f".format(rmse2))
    } else {
      println("============== tuning parameters(Category) ==================")
      tuneParameter(trainDataWithMap, validateDataWithMap)
    }

    trainDataWithMap.unpersist(); validateDataWithMap.unpersist();
  }
  
  def prepareCategoryMap(fieldName: String, bikeData: RDD[BikeShareEntity]): Map[Double, Int] = {
    val categoryMap = bikeData.map { x => x.getField(fieldName) }.distinct().collect().zipWithIndex.toMap
    categoryMap
  }

  def prepare(sc: SparkContext): 
  (RDD[LabeledPoint], RDD[LabeledPoint]) = {
    val rawData = Utility.readFile(sc, "hour.csv")

    MyLogger.debug("read BikeShare Dateset count=" + rawData.count())
    val bikeData = rawData.map { x => new BikeShareEntity(x) }
    
    val yrMap = prepareCategoryMap("yr", bikeData)
    val seasonMap = prepareCategoryMap("season", bikeData)
    val mnthMap = prepareCategoryMap("mnth", bikeData)
    val holidayMap = prepareCategoryMap("holiday", bikeData)
    val weekdayMap = prepareCategoryMap("weekday", bikeData)
    val workdayMap = prepareCategoryMap("workingday", bikeData)
    val weatherMap = prepareCategoryMap("weathersit", bikeData)
    val hrMap = prepareCategoryMap("hr", bikeData)
    val Array(bikeDataT, bikeDataV) = bikeData.randomSplit(Array(0.6, 0.4))
    //Standardize 
    val featureRddWithMap = bikeData.map { x => 
      Vectors.dense(x.getFeatures(yrMap, seasonMap, mnthMap, hrMap, holidayMap, weekdayMap, workdayMap, weatherMap)) 
    }
 		val stdScalerWithMap = new StandardScaler(withMean=true, withStd=true).fit(featureRddWithMap)
    //處理Category feature
    val trainDataWithMap = bikeDataT.map { x =>
      {
        val label = x.getLabel()
        val features = 
          stdScalerWithMap.transform(Vectors.dense(x.getFeatures(yrMap, seasonMap, mnthMap, hrMap, holidayMap, weekdayMap, workdayMap, weatherMap)))
        new LabeledPoint(label, features)
      }
    }
    val validateDataWithMap = bikeDataV.map { x =>
      {
        val label = x.getLabel()
        val features = 
          stdScalerWithMap.transform(Vectors.dense(x.getFeatures(yrMap, seasonMap, mnthMap, hrMap, holidayMap, weekdayMap, workdayMap, weatherMap)))
        new LabeledPoint(label, features)
      }
    }
    (trainDataWithMap, validateDataWithMap)
  }

  def trainModel(trainData: RDD[LabeledPoint],
                 numIterations: Int, stepSize: Double, miniBatchFraction: Double): 
                 (LinearRegressionModel, Double) = {
    val startTime = new DateTime()
    
    val model = LinearRegressionWithSGD.train(trainData, numIterations, stepSize, miniBatchFraction) 
    val endTime = new DateTime()
    val duration = new Duration(startTime, endTime)
    //MyLogger.debug(model.toPMML())
    (model, duration.getMillis)
  }

  def evaluateModel(validateData: RDD[LabeledPoint], model: LinearRegressionModel): Double = {
    val scoreAndLabels = validateData.map { data =>
      var predict = model.predict(data.features)
      (predict, data.label)
    }
    val metrics = new RegressionMetrics(scoreAndLabels)
    val rmse = metrics.rootMeanSquaredError
    rmse
  }

  def tuneParameter(trainData: RDD[LabeledPoint], validateData: RDD[LabeledPoint]) = {
    val iterationArr: Array[Int] = Array(5, 10, 20, 60,100)
    val stepSizeArr: Array[Double] = Array(0.01, 0.025, 0.05, 0.1,1.0)
    val miniBatchFractionArr: Array[Double] = Array(0.5,0.8, 1)
    val evalArr =
      for (iteration <- iterationArr; stepSize <- stepSizeArr;miniBatchFraction <- miniBatchFractionArr) yield {
        val (model, duration) = trainModel(trainData, iteration, stepSize,miniBatchFraction)
        val rmse = evaluateModel(validateData, model)
        println("parameter: iteraion=%d, stepSize=%f, miniBatchFraction=%f, rmse=%f"
          .format(iteration, stepSize,miniBatchFraction, rmse))
        (iteration, stepSize,miniBatchFraction, rmse)
      }
    val bestEvalAsc = (evalArr.sortBy(_._4))
    val bestEval = bestEvalAsc(0)
    println("best parameter: iteraion=%d, stepSize=%f,miniBatchFraction=%f, rmse=%f"
      .format(bestEval._1, bestEval._2, bestEval._3, bestEval._4))
  }
}