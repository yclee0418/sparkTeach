package com.util

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._
import org.apache.spark.mllib.evaluation._

object Utility {
  def isNumeric(input: String): Boolean = input.trim().matches(s"""[+-]?((\\d+(e\\d+)?[lL]?)|(((\\d+(\\.\\d*)?)|(\\.\\d+))(e\\d+)?[fF]?))""")
  
  def toFloat(input: String): Float = {
    val rtn = if (input.isEmpty() || !isNumeric(input)) Float.NaN else input.toFloat
    rtn
  }
  
  def toDouble(input: String): Double = {
    val rtn = if (input.isEmpty() || !isNumeric(input)) Double.NaN else input.toDouble
    rtn
  }
  
  /*
   * 四拾五入
   */
  def round(input: Double, digit:Int) : Double = {
    val res = BigDecimal(input).setScale(digit, BigDecimal.RoundingMode.HALF_UP).toDouble
    res
  }
  
  def readFile(sc: org.apache.spark.SparkContext, fileName: String): RDD[Array[String]] = {
    val rawDataWithHead = sc.textFile("data/" + fileName)
    val rawData = rawDataWithHead.mapPartitionsWithIndex { (idx, iter) => { if (idx == 0) iter.drop(1) else iter } }
    val lines = rawData.map { x => x.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1).map { x => x.trim() } }
    lines
  }   
}