package bike

//spark lib
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

//com.util
import com.util._

//log
import org.apache.log4j.Logger

//summary statistics
import org.apache.spark.mllib.linalg._
import org.apache.spark.mllib.stat.{ MultivariateStatisticalSummary, Statistics }

//clusting
import org.apache.spark.mllib.clustering.{ KMeans, KMeansModel }

object BikeSummary {
  def main(args: Array[String]): Unit = {
    //MyLogger.initializeLogging
    MyLogger.setLogger
    val sc = new SparkContext(new SparkConf().setAppName("BikeSummary").setMaster("local[4]"))

    println("============== preparing data ==================")
    val bikeData = prepare(sc)
    bikeData.persist()
    println("============== print summary statistics ==================")
    printSummary(bikeData)
    println("============== print Correlation ==================")
    printCorrelation(bikeData)
    bikeData.unpersist()
  }

  def prepare(sc: SparkContext): RDD[BikeShareEntity] = {
    val rawData = Utility.readFile(sc, "hour.csv")
    //val rawData = Utility.readFile(sc, "day.csv")

    MyLogger.debug("read BikeShare Dateset count=" + rawData.count())
    val bikeData = rawData.map { x => new BikeShareEntity(x) }
    bikeData
  }

  def printSummary(entRdd: RDD[BikeShareEntity]) = {
    val dvRdd = entRdd.map { x => Vectors.dense(x.getFeatures()) }
    val summaryAll = Statistics.colStats(dvRdd)
    println("====== summary all ==========")
    //println("mean:" + summaryAll.mean) // a dense vector containing the mean value for each column
    println("mean:" + BikeShareEntity.getSummaryDisp(summaryAll.mean.toArray))
    //println("variance:" + summaryAll.variance) // column-wise variance
    println("variance:" + BikeShareEntity.getSummaryDisp(summaryAll.variance.toArray))
    //println("noneZero Cnt:" + summaryAll.numNonzeros) // number of nonzeros in each column
    println("noneZero Cnt:" + BikeShareEntity.getSummaryDisp(summaryAll.numNonzeros.toArray))
  }

  def printCorrelation(entRdd: RDD[BikeShareEntity]) = {
    val cntRdd = entRdd.map { x => x.getField("cnt") }
    val ent: BikeShareEntity = entRdd.take(1)(0)
    val fieldCols = BikeShareEntity.featureCols_hour
    for (idx <- 0 to fieldCols.length - 1) /*yield*/ {
      val fieldNm = fieldCols(idx)
      if (!",cnt,dteday,".contains(fieldNm)) {
        val fieldRdd = entRdd.map { x => x.getField(fieldNm) }
        val corr = Statistics.corr(fieldRdd, cntRdd)
        println("correlation: %s vs %s: %f".format(fieldNm, "cnt", corr))
      }
    }
  }
}