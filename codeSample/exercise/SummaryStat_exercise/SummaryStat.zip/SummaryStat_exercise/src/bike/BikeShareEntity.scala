package bike

import com.util._
import scala.collection.mutable.Map
import scala.collection.immutable.{ Map => ImmMap }
import java.util.Collection

class BikeShareEntity extends Serializable {
  //========= member declare ===========
  var valMap: Map[String, String] = Map[String, String]()
  val columns_hour = BikeShareEntity.columns_hour
  val featureCols_hour = BikeShareEntity.featureCols_hour
  //constructor   
  def this(fields: Array[String]) = {
    this();
  
    if (fields.length == columns_hour.length) {
      for (i <- 0 to columns_hour.length - 1) {
        valMap += (columns_hour(i) -> fields(i).trim())
      }
    } else {
      throw new IllegalArgumentException("number of fields: %d, should be %d !"
        .format(fields.length, columns_hour.length))
    }
  }

  def getAllFieldDisp(): String = {
    var cols: Array[String] = Array()
    cols = columns_hour
    val rtnStr = cols.map { x => "%s:%s".format(x, valMap(x)) }.mkString(", ")
    rtnStr
  }

  /*
   * 取得K-Means使用之features
   */
  def getFeatures(): Array[Double] = {
    var rtnArr: Array[Double] = Array()
    val featureCols = featureCols_hour
    for (i <- 0 to featureCols.length - 1) {
      featureCols(i) match {
        case "mnth" | "weathersit" | "season" | "yrmo" => rtnArr = rtnArr ++ Array(Utility.toDouble(valMap(featureCols(i))) - 1)
        case _                                => rtnArr = rtnArr ++ Array(Utility.toDouble(valMap(featureCols(i))))
      }

    }
    
  
    rtnArr
  }

  /**
   * 取得指定欄位值
   */
  def getField(fieldName: String): Double = {
    val fv = Utility.toDouble(valMap(fieldName))
    fv
  }
}

object BikeShareEntity {
  val columns_hour: Array[String] = Array("instant", "dteday", "season", "yr", "mnth", "hr", "holiday", "weekday", "workingday", "weathersit", "temp", "atemp", "hum", "windspeed", "casual", "registered", "cnt")
  /*
   * 特徵值欄位(day)
   */
  val featureCols_day: Array[String] = Array("yr", "season", "mnth", "holiday", "weekday", "workingday", "weathersit", "temp", "atemp", "hum", "windspeed")
  /*
   * 特徵值欄位(hour)
   */
  val featureCols_hour: Array[String] = Array("yr", "season", "mnth", "hr", "holiday", "weekday", "workingday", "weathersit", "temp", "atemp", "hum", "windspeed")

  val categoryInfoMap = Map[String, Int](("season", 4), ("yr", 2), ("mnth", 12), ("hr", 24),
    ("holiday", 2), ("weekday", 7), ("workingday", 2), ("weathersit", 4),("yrmo",24))
  def getSummaryDisp(vsArr: Array[Double]): String = {
    val featureCols = featureCols_hour
    var dispArr: Array[String] = Array()
    for (i <- 0 to featureCols.length - 1) {
      dispArr ++= Array("%s: %s".format(featureCols(i), Utility.round(vsArr(i), 5)))
    }
    val dispStr = "[%s]".format(dispArr.mkString(", "))
    dispStr
  }

  def getCategoryInfo(): ImmMap[Int, Int] = {
    val categoryInfo = categoryInfoMap.map {
      x =>
        {
          var idx = -1
          idx = featureCols_hour.indexOf(x._1)
          (idx, x._2)
        }
    }.filter(_._1 > 0).toMap
    categoryInfo
  }
}