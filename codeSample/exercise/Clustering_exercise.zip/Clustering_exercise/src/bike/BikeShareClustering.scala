package bike

//spark lib
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

//com.util
import com.util._

//log
import org.apache.log4j.Logger

//summary statistics
import org.apache.spark.mllib.linalg._
import org.apache.spark.mllib.stat.{ MultivariateStatisticalSummary, Statistics }

//clusting
import org.apache.spark.mllib.clustering.{ KMeans, KMeansModel }

object BikeShareClustering {
  def main(args: Array[String]): Unit = {
    //MyLogger.initializeLogging
    MyLogger.setLogger
    val sc = new SparkContext(new SparkConf().setAppName("BikeShareClustering").setMaster("local[4]"))

    println("============== preparing data ==================")
    val bikeData = prepare(sc)
    bikeData.persist()
    println("============== clusting by KMeans ==================")
    val featureRdd = bikeData.map { x => Vectors.dense(x.getFeatures()) }
    val model = KMeans.train(featureRdd, 5, 20, 3)
    
    var clusterIdx = 0   
    model.clusterCenters.sortBy { x => x(x.size-1) }.foreach { x => {
    	println("center of cluster %d:\n%s".format(clusterIdx, BikeShareEntity.getSummaryDisp(x.toArray) ))      
    	clusterIdx += 1
    } }
    println("============== tuning parameters ==================")
    for (k <- Array(5,10,15,20, 25, 35, 50,75,100)) {
      val iterations = 20
      val tm = KMeans.train(featureRdd, k, iterations,3)
      println("k=%d, WCSS=%f".format(k, tm.computeCost(featureRdd)))
    }
    bikeData.unpersist()
  }

  def prepare(sc: SparkContext): RDD[BikeShareEntity] = {
    val rawData = Utility.readFile(sc, "hour.csv")

    MyLogger.debug("read BikeShare Dateset count=" + rawData.count())
    val bikeData = rawData.map { x => new BikeShareEntity(x) }
    bikeData
  }

}