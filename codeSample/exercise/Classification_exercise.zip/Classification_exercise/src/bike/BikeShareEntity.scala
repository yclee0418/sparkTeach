package bike

import com.util._
import scala.collection.mutable.Map
import scala.collection.immutable.{ Map => ImmMap }
import java.util.Collection

class BikeShareEntity extends Serializable {
  //========= member declare ===========
  var valMap: Map[String, String] = Map[String, String]()
  
  //constructor   
  def this(fields: Array[String]) = {
    this();
    
    if (fields.length == BikeShareEntity.columns_hour.length) {
      for (i <- 0 to BikeShareEntity.columns_hour.length - 1) {
        valMap += (BikeShareEntity.columns_hour(i) -> fields(i).trim())
      }
    } else {
      throw new IllegalArgumentException("number of fields: %d, should be %d !"
        .format(fields.length, BikeShareEntity.columns_hour.length))
    }
  }

  def getAllFieldDisp(): String = {
    var cols: Array[String] = Array()
    
      cols = BikeShareEntity.columns_hour
    val rtnStr = cols.map { x => "%s:%s".format(x, valMap(x)) }.mkString(", ")
    rtnStr
  }

  /*
   * 取得演算法使用之features
   */
  def getFeatures(): Array[Double] = {
    var rtnArr: Array[Double] = Array()
    val featureCols = BikeShareEntity.featureCols_hour
    for (i <- 0 to featureCols.length - 1) {
      featureCols(i) match {
        case "mnth" | "weathersit" | "season" => rtnArr = rtnArr ++ Array(Utility.toDouble(valMap(featureCols(i)))-1)
        case _ => rtnArr = rtnArr ++ Array(Utility.toDouble(valMap(featureCols(i)))) 
      }
      
    }
    rtnArr
  }

  /**
   * 取得featureArray(1-of-k encoding)
   */
  def getFeatures(yrMap: ImmMap[Double, Int], seasonMap: ImmMap[Double, Int], mnthMap: ImmMap[Double, Int],
                  hrMap: ImmMap[Double, Int], holidayMap: ImmMap[Double, Int], weekdayMap: ImmMap[Double, Int], workdayMap: ImmMap[Double, Int],
                  weatherMap: ImmMap[Double, Int]): Array[Double] = {
    var rtnArr: Array[Double] = Array()
    val featureCols = BikeShareEntity.featureCols_hour
    for (i <- 0 to featureCols.length - 1) {
      featureCols(i) match {
        case "yr"         => rtnArr = rtnArr ++ getCategoryFeature("yr", yrMap)
        case "season"     => rtnArr = rtnArr ++ getCategoryFeature("season", seasonMap)
        case "mnth"       => rtnArr = rtnArr ++ getCategoryFeature("mnth", mnthMap)
        case "holiday"    => rtnArr = rtnArr ++ getCategoryFeature("holiday", holidayMap)
        case "weekday"    => rtnArr = rtnArr ++ getCategoryFeature("weekday", weekdayMap)
        case "workingday" => rtnArr = rtnArr ++ getCategoryFeature("workingday", workdayMap)
        case "weathersit" => rtnArr = rtnArr ++ getCategoryFeature("weathersit", weatherMap)
        case "hr"         => rtnArr = rtnArr ++ getCategoryFeature("hr", hrMap)
        case _            => rtnArr = rtnArr ++ Array(Utility.toDouble(valMap(featureCols(i))))
      }
    }
    rtnArr
  }

  /**
   * 將Category的Feature("yr","season","mnth","holiday","weekday","workingday","weathersit")轉成1-of-k encode的編碼Array
   */
  def getCategoryFeature(fieldName: String, categoryMap: ImmMap[Double, Int]): Array[Double] = {
    var featureArray = Array.ofDim[Double](categoryMap.size)
    val index = categoryMap(getField(fieldName))
    featureArray(index) = 1
    featureArray
  }

  /**
   * 取得指定欄位值
   */
  def getField(fieldName: String): Double = {
    val fv = Utility.toDouble(valMap(fieldName))
    fv
  }

  def getLabel(): Double = {
    val cnt = Utility.toDouble(valMap("cnt"))
    //val label: Double = if (cnt >= 5400) 1 else 0 //day: 5400
    val label: Double = if (cnt > 200) 1 else 0 //hour: 200
    label //Classification Label:是/否
  }
}

object BikeShareEntity {
  val columns_hour: Array[String] = Array("instant", "dteday", "season", "yr", "mnth", "hr", "holiday", "weekday", "workingday", "weathersit", "temp", "atemp", "hum", "windspeed", "casual", "registered", "cnt")
  /*
   * 特徵值欄位(hour)
   */
  val featureCols_hour: Array[String] = Array("yr", "season", "mnth", "hr", "holiday", "weekday", "workingday", "weathersit", "temp", "atemp", "hum", "windspeed")
  //val featureCols_hour: Array[String] = Array("yr", "season", "mnth", "hr", "holiday", "weekday", "workingday", "weathersit", "temp", "atemp", "hum", "windspeed")

  val categoryInfoMap = Map[String, Int](("season", 4), ("yr", 2), ("mnth", 12), ("hr", 24),
    ("holiday", 2), ("weekday", 7), ("workingday", 2), ("weathersit", 4))
  def getSummaryDisp(vsArr: Array[Double]): String = {
    val featureCols = featureCols_hour 
    var dispArr: Array[String] = Array()
    for (i <- 0 to featureCols.length - 1) {
      dispArr ++= Array("%s: %s".format(featureCols(i), Utility.round(vsArr(i), 5)))
    }
    val dispStr = "[%s]".format(dispArr.mkString(", "))
    dispStr
  }

  def getCategoryInfo(): ImmMap[Int, Int] = {
    val categoryInfo = categoryInfoMap.map {
      x =>
        {
          var idx = -1
          idx = featureCols_hour.indexOf(x._1)
          (idx, x._2)
        }
    }.filter(_._1 > 0).toMap
    categoryInfo
  }
}