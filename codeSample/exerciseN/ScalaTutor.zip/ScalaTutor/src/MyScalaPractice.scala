

object MyScalaPractice {
  //practice1: 定義case class
  case  class BikeData(id:String, date:String, hour:Int, cnt: Int)
  
  def main(args: Array[String]): Unit = {
    //practice2: 建立BikeData Array，並加入5個element
    var bikeArray: Array[BikeData] = Array()
    bikeArray ++= Array(BikeData("1", "20110101", 7, 300))
    bikeArray ++= Array(BikeData("2", "20110101", 8, 420))
    bikeArray ++= Array(BikeData("3", "20110102", 6, 340))
    bikeArray ++= Array(BikeData("4", "20110102", 8, 240))
    bikeArray ++= Array(BikeData("5", "20110103", 7, 590))
    
    //practice3: 找出租借量(cnt)大於350者，印出bikeData內容(限用filter功能)
    println("=====找出租借量(cnt)大於350者=====")
    bikeArray.filter { x => x.cnt > 350 }.foreach(println)
    
    //practice4: 計算bikeArray中cnt的總合(提示：使用map功能將cnt值取成Array[Int]後，呼叫Array[Int]的sum方法取得)
    val sum = bikeArray.map { x => x.cnt }.sum
    
    //practice5: 取得bikeArray中cnt的最大及最小值(提示：使用map功能將cnt值取成Array[Int]後，分別呼叫Array[Int]的min及max方法取得)
    val max = bikeArray.map { x => x.cnt }.max
    val min = bikeArray.map { x => x.cnt }.min
    println("=====cnt的總合：%d, 最大值：%d, 最小值：%d=====".format(sum, max, min))
    
    //practice6: 以date欄位為key，grouping計算每日(date)的cnt總合，以(date, sumOfCnt)格式列印在console
    //提示：以date欄位取distinct，用for迴圈＋filter功能取得每日的bikeData，再用practice4的方法計算每日的sum
    //以yield關鍵字，讓for迴圈結果組成Array[(date, sumOfCnt)]
    val dateDisc = bikeArray.map{x => x.date}.distinct
    val dateSum = 
      for (date <- dateDisc) yield {
        val sumOfCnt = bikeArray.filter { x => x.date.equals(date) }.map { x => x.cnt }.sum
        (date, sumOfCnt)
      }
    println("=====以date欄位為key，grouping計算每日(date)的cnt總合=====")
    dateSum.foreach(println)
  }
}