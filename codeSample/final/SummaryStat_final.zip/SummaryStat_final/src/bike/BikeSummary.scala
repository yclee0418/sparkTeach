package bike

//spark lib
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

//com.util
import com.util._

//log
import org.apache.log4j.Logger

//summary statistics
import org.apache.spark.mllib.linalg._
import org.apache.spark.mllib.stat.{ MultivariateStatisticalSummary, Statistics }

//clusting
import org.apache.spark.mllib.clustering.{ KMeans, KMeansModel }

object BikeSummary {
  def main(args: Array[String]): Unit = {
    //MyLogger.initializeLogging
    MyLogger.setLogger
    val sc = new SparkContext(new SparkConf().setAppName("BikeSummary").setMaster("local[4]"))

    println("============== preparing data ==================")
    val bikeData = prepare(sc)
    bikeData.persist()
    println("============== print summary statistics ==================")
    printSummary(bikeData)
    //    println("============== print Correlation ==================")
    //    printCorrelation(bikeData)
    bikeData.unpersist()
  }

  def prepare(sc: SparkContext): RDD[BikeShareEntity] = {
    val rawData = Utility.readFile(sc, "hour.csv")
    //val rawData = Utility.readFile(sc, "day.csv")

    MyLogger.debug("read BikeShare Dateset count=" + rawData.count())
    val bikeData = rawData.map { x => new BikeShareEntity(x) }
    bikeData
  }

  def printSummary(entRdd: RDD[BikeShareEntity]) = {
    val dvRdd = entRdd.map { x => Vectors.dense(x.getFeatures()) }
    val summaryAll = Statistics.colStats(dvRdd)
    println("====== summary all ==========")
    // a dense vector containing the mean value for each column
    println("mean:" + BikeShareEntity.getSummaryDisp(summaryAll.mean.toArray))
    // column-wise variance
    println("variance:" + BikeShareEntity.getSummaryDisp(summaryAll.variance.toArray))
    // number of nonzeros in each column
    println("noneZero Cnt:" + BikeShareEntity.getSummaryDisp(summaryAll.numNonzeros.toArray))
  
    //exercise 解答
    for (yr <- 0 to 1) {
        for (mnth <- 1 to 12) {
          val yrMnRdd = entRdd.filter { x => (x.getField("yr") == yr 
                && x.getField("mnth") == mnth)}
          val summaryYrMn = Statistics.colStats(yrMnRdd.map { x => Vectors.dense(x.getFeatures()) })
          println("====== summary yr=%d, mnth=%d ==========".format(yr,mnth))
          println("mean:" + BikeShareEntity.getSummaryDisp(summaryYrMn.mean.toArray))
          println("variance:" + BikeShareEntity.getSummaryDisp(summaryYrMn.variance.toArray))
        }
    }
  }

  def printCorrelation(entRdd: RDD[BikeShareEntity]) = {
    val cntRdd = entRdd.map { x => x.getField("cnt") }
    val ent: BikeShareEntity = entRdd.take(1)(0)
    val fieldCols = BikeShareEntity.featureCols_hour
    for (idx <- 0 to fieldCols.length - 1) /*yield*/ {
      val fieldNm = fieldCols(idx)
      if (!",cnt,dteday,".contains(fieldNm)) {
        val fieldRdd = entRdd.map { x => x.getField(fieldNm) }
        val corr = Statistics.corr(fieldRdd, cntRdd)
        println("correlation: %s vs %s: %f".format(fieldNm, "cnt", corr))
      }
    }
    //Exercise解答: 計算yr+mnth與cnt的corr
    val yrmnthRdd = entRdd.map { x => x.getField("yr") * 12 + x.getField("mnth") }
    val corrYrmnCnt = Statistics.corr(yrmnthRdd,cntRdd)
 		println("correlation: %s vs %s: %f".format("yr+mnth", "cnt", corrYrmnCnt))

 		//Exercise解答: 計算dayType與casual、registered的Corr
 		val dayTypeRdd = entRdd.map { x => x.getField("dayType") }
    val casualRdd = entRdd.map { x => x.getField("casual") }
    val regRdd = entRdd.map { x => x.getField("registered") }
    val corrCas = Statistics.corr(dayTypeRdd, casualRdd);
    println("correlation: %s vs %s: %f".format("dayType", "casual", corrCas))
    val regCas = Statistics.corr(dayTypeRdd, regRdd);
    println("correlation: %s vs %s: %f".format("dayType", "registered", regCas))

  }
}