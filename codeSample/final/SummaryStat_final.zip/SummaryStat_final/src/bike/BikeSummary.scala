package bike

//spark lib
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

//log
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.log4j._

//summary statistics
import org.apache.spark.mllib.linalg._
import org.apache.spark.mllib.stat.{ MultivariateStatisticalSummary, Statistics }

object BikeSummary {
  case class BikeShareEntity(instant: String,	dteday:String,	season:Double,	yr:Double,	mnth:Double,
      hr:Double,	holiday:Double,	weekday:Double,	workingday:Double,	weathersit:Double,	temp:Double,
      atemp:Double,	hum:Double,	windspeed:Double,	casual:Double,	registered:Double,	cnt:Double, yrmo:Double )
  
  def main(args: Array[String]): Unit = {
    setLogger
    val sc = new SparkContext(new SparkConf().setAppName("BikeSummary").setMaster("local[*]"))

    println("============== preparing data ==================")
    val bikeData = prepare(sc)
    bikeData.persist()
    println("============== print summary statistics ==================")
    printSummary(bikeData)
    println("============== print Correlation ==================")
    printCorrelation(bikeData)
    bikeData.unpersist()
  }

  def prepare(sc: SparkContext): RDD[BikeShareEntity] = {
    val rawDataWithHead = sc.textFile("data/hour.csv")
    val rawDataNoHead = rawDataWithHead.mapPartitionsWithIndex { (idx, iter) => { if (idx == 0) iter.drop(1) else iter } }
    val rawData = rawDataNoHead.map { x => x.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1).map { x => x.trim() } }

    println("read BikeShare Dateset count=" + rawData.count())
    val bikeData = rawData.map { x =>
      BikeShareEntity(x(0), x(1), x(2).toDouble, x(3).toDouble,x(4).toDouble, 
      x(5).toDouble,	x(6).toDouble,	x(7).toDouble,	x(8).toDouble,	x(9).toDouble,	x(10).toDouble,    
      x(11).toDouble,	x(12).toDouble,	x(13).toDouble,	x(14).toDouble,	x(15).toDouble,	x(16).toDouble, x(3).toDouble*12+x(4).toDouble)
      }
    bikeData
  }
  
  def getFeatures(bikeData: BikeShareEntity): Array[Double] = {
    val featureArr = Array(bikeData.temp, bikeData.hum, bikeData.windspeed, 
        bikeData.casual, bikeData.registered,bikeData.cnt)
    featureArr
  }

  def printSummary(entRdd: RDD[BikeShareEntity]) = {
    val dvRdd = entRdd.map { x => Vectors.dense(getFeatures(x)) }
    val summaryAll = Statistics.colStats(dvRdd)
    println("====== summary all ==========")
    // a dense vector containing the mean value for each column
    println("%1$-13s:".format("mean") + summaryAll.mean.toArray.map { x => "%1$9s".format(round(x, 3)) }.mkString(", ")); 
    // column-wise variance
    println("%1$-13s:".format("variance") + summaryAll.variance.toArray.map { x => "%1$9s".format(round(x, 3)) }.mkString(", ")); 
    // number of nonzeros in each column
    println("%1$-13s:".format("noneZero Cnt") + summaryAll.numNonzeros.toArray.map { x => "%1$9s".format(round(x, 3)) }.mkString(", ")); 
  
    
    for (yr <- 0 to 1) 
    for (mnth <- 1 to 12) {
        val yrMnRdd = entRdd.filter { x=>x.yr == yr && x.mnth == mnth}.map { x => Vectors.dense(getFeatures(x)) }
        val summaryYrMn = Statistics.colStats( yrMnRdd )
        println("====== summary yr=%d, mnth=%d ==========".format(yr,mnth))
        println("%1$-13s:".format("mean") + summaryYrMn.mean.toArray.map { x => "%1$9s".format(round(x, 3)) }.mkString(", ")); 
    // column-wise variance
    println("%1$-13s:".format("variance") + summaryYrMn.variance.toArray.map { x => "%1$9s".format(round(x, 3)) }.mkString(", "));
    }

  }

  def printCorrelation(entRdd: RDD[BikeShareEntity]) = {
    val cntRdd = entRdd.map { x => x.cnt }    
    val yrRdd = entRdd.map { x => x.yr }
    val yrCorr = Statistics.corr(yrRdd, cntRdd)
    println("correlation: %s vs %s: %f".format("yr", "cnt", yrCorr))
    val hrRdd = entRdd.map { x => x.hr }
    val hrCorr = Statistics.corr(hrRdd, cntRdd)
    println("correlation: %s vs %s: %f".format("hr", "cnt", hrCorr))
    val yrmoRdd = entRdd.map { x => x.yrmo }
    val yrmoCorr = Statistics.corr(yrmoRdd, cntRdd)
    println("correlation: %s vs %s: %f".format("yrmo", "cnt", yrmoCorr))
  }
  
  def setLogger = {
    Logger.getLogger("org").setLevel(Level.OFF)//mark for MLlib INFO msg
    Logger.getLogger("com").setLevel(Level.OFF)
    Logger.getLogger("io").setLevel(Level.OFF)
    System.setProperty("spark.ui.showConsoleProgress", "false")
    Logger.getRootLogger().setLevel(Level.ALL);
  }
  
  /*
   * 四拾五入
   */
  def round(input: Double, digit:Int) : Double = {
    val res = BigDecimal(input).setScale(digit, BigDecimal.RoundingMode.HALF_UP).toDouble
    res
  }
}