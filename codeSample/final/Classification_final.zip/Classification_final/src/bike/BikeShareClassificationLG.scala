package bike

//time lib
import org.joda.time._
//spark lib
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

//com.util
import com.util._

//log
import org.apache.log4j.Logger

//summary statistics
import org.apache.spark.mllib.linalg._
import org.apache.spark.mllib.stat.{ MultivariateStatisticalSummary, Statistics }

//MLlib lib
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.evaluation._
import org.apache.spark.mllib.linalg.Vectors

//Logistic
import org.apache.spark.mllib.feature.StandardScaler
import org.apache.spark.mllib.classification.{ LogisticRegressionWithSGD, LogisticRegressionModel }

/**
 * BikeShare predict by LogisticRegression
 */
object BikeShareClassificationLG {
  def main(args: Array[String]): Unit = {
    MyLogger.setLogger

    val doTrain = (args != null && args.length > 0 && "Y".equals(args(0)))

    val sc = new SparkContext(new SparkConf().setAppName("BikeShareClassificationLG").setMaster("local[4]"))

    println("============== preparing data ==================")
    val (trainDataWithMap, validateDataWithMap) = prepare(sc)
    trainDataWithMap.persist(); validateDataWithMap.persist();

    if (!doTrain) {
      println("============== train Model (Category) ==================")
      val (model2, duration2) = trainModel(trainDataWithMap, 10, 1, 1)
      val auc2 = evaluateModel(validateDataWithMap, model2)
      println("validate auc(category)=%f".format(auc2))
    } else {
      println("============== tuning parameters(Category) ==================")
      tuneParameter(trainDataWithMap, validateDataWithMap)
    }

    trainDataWithMap.unpersist(); validateDataWithMap.unpersist();
  }

  def prepareCategoryMap(fieldName: String, bikeData: RDD[BikeShareEntity]): Map[Double, Int] = {
    val categoryMap = bikeData.map { x => x.getField(fieldName) }.distinct().collect().zipWithIndex.toMap
    categoryMap
  }

  def prepare(sc: SparkContext): (RDD[LabeledPoint], RDD[LabeledPoint]) = {
    val rawData = Utility.readFile(sc, "hour.csv")

    MyLogger.debug("read BikeShare Dateset count=" + rawData.count())
    val bikeData = rawData.map { x => new BikeShareEntity(x) }
    val yrMap = prepareCategoryMap("yr", bikeData)
    val seasonMap = prepareCategoryMap("season", bikeData)
    val mnthMap = prepareCategoryMap("mnth", bikeData)
    val holidayMap = prepareCategoryMap("holiday", bikeData)
    val weekdayMap = prepareCategoryMap("weekday", bikeData)
    val workdayMap = prepareCategoryMap("workingday", bikeData)
    val weatherMap = prepareCategoryMap("weathersit", bikeData)
    val hrMap = prepareCategoryMap("hr", bikeData)
    //Standardize 
    val featureRddWithMap = bikeData.map { x => 
      Vectors.dense(x.getFeatures(yrMap, seasonMap, mnthMap, hrMap, holidayMap, weekdayMap, workdayMap, weatherMap)) 
    } 
 		val stdScalerWithMap = new StandardScaler(withMean=true, withStd=true).fit(featureRddWithMap)
    val Array(bikeDataT, bikeDataV) = bikeData.randomSplit(Array(0.6, 0.4))
    //處理Category feature
    val trainDataWithMap = bikeDataT.map { x =>
      {
        val label = x.getLabel()
        val features = /*Vectors.dense(x.getFeatures()) =>取消對Categorical欄位作1-of-K encoding、以及不要作標準化*/
          stdScalerWithMap.transform(Vectors.dense(x.getFeatures(yrMap, seasonMap, mnthMap, hrMap, holidayMap, weekdayMap, workdayMap, weatherMap)))
        new LabeledPoint(label, features)
      }
    }
    val validateDataWithMap = bikeDataV.map { x =>
      {
        val label = x.getLabel()
        val features = /*Vectors.dense(x.getFeatures()) =>取消對Categorical欄位作1-of-K encoding、以及不要作標準化*/
          stdScalerWithMap.transform(Vectors.dense(x.getFeatures(yrMap, seasonMap, mnthMap, hrMap, holidayMap, weekdayMap, workdayMap, weatherMap)))
        new LabeledPoint(label, features)
      }
    }
    (trainDataWithMap, validateDataWithMap)
  }

  def trainModel(trainData: RDD[LabeledPoint],
                 numIterations: Int, stepSize: Double, miniBatchFraction: Double): 
                 (LogisticRegressionModel, Double) = {
    val startTime = new DateTime()
    val model =  
      LogisticRegressionWithSGD.train(trainData, numIterations, stepSize, miniBatchFraction)
    val endTime = new DateTime()
    val duration = new Duration(startTime, endTime)
 
    //MyLogger.debug(model.toPMML())
    (model, duration.getMillis)
  }

  def evaluateModel(validateData: RDD[LabeledPoint], model: LogisticRegressionModel): Double = {
    val scoreAndLabels = validateData.map { data =>
      var predict = model.predict(data.features)
      (predict, data.label)
    }
    val metrics = new BinaryClassificationMetrics(scoreAndLabels)
    val auc = metrics.areaUnderROC()
    auc
  }

  def tuneParameter(trainData: RDD[LabeledPoint], validateData: RDD[LabeledPoint]) = {
    val iterationArr: Array[Int] = Array(5, 10, 20, 60,100)
    val stepSizeArr: Array[Double] = Array(10, 50, 100, 200)
    val miniBatchFractionArr: Array[Double] = Array(0.5,0.8, 1)
    val evalArr =
      for (iteration <- iterationArr; stepSize <- stepSizeArr; miniBatchFraction <- miniBatchFractionArr) yield {
        val (model, duration) = trainModel(trainData, iteration, stepSize, miniBatchFraction)
        val auc = evaluateModel(validateData, model)
        println("parameter: iteraion=%d, stepSize=%f, miniBatchFraction=%f, auc=%f, duration=%f"
          .format(iteration, stepSize, miniBatchFraction, auc, duration))
        (iteration, stepSize, miniBatchFraction, auc, duration)
      }
    //Exercise解答：取AUC前三好的Model，在console中印出參數組合及花費時間
    val bestEval3 = (evalArr.sortBy(_._4).reverse).take(3)
    bestEval3.foreach(bestEval =>
      println("best parameter: impurity=%s, maxDepth=%d, maxBins=%d, auc=%f, duration=%f"
        .format(bestEval._1, bestEval._2, bestEval._3, bestEval._4, bestEval._5)))
  }
}