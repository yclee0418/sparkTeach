package com.util

//log
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.log4j._

import java.io._

object MyLogger extends Serializable {
  @transient lazy val log = Logger.getRootLogger
  
  def setLogger = {
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("com").setLevel(Level.OFF)
    Logger.getLogger("io").setLevel(Level.OFF)
    System.setProperty("spark.ui.showConsoleProgress", "false")
    Logger.getRootLogger().setLevel(Level.DEBUG);
  }
  
  def initializeLogging = {
    val appender: ConsoleAppender  = new ConsoleAppender
    appender.setWriter(new PrintWriter(System.out));
    appender.setLayout(new PatternLayout(PatternLayout.TTCC_CONVERSION_PATTERN));
    appender.setName("stdout");
    Logger.getRootLogger().addAppender(appender);
  }
  
  def debug(msg: String) = {
    //log.debug(msg)
    println(msg)
  }
}